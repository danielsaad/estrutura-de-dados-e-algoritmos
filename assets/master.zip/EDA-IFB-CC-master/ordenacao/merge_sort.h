#ifndef MERGE_SORT_H_INCLUDED
#define MERGE_SORT_H_INCLUDED
#include <stdlib.h>

void merge_sort(int* v,size_t size);

#endif
