#ifndef QUICK_SORT_H_INCLUDED
#define QUICK_SORT_H_INCLUDED
#include <stdlib.h>

void quick_sort(int* v,size_t size);

#endif
