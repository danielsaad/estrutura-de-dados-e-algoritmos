#ifndef COUNTING_SORT_H_INCLUDED
#define COUNTING_SORT_H_INCLUDED
#include <stdlib.h>

void counting_sort(int* v,size_t size);

#endif
