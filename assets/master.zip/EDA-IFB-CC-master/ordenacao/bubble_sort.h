#ifndef BUBBLE_SORT_H_INCLUDED
#define BUBBLE_SORT_H_INCLUDED
#include <stdlib.h>

void bubble_sort(int* v,size_t size);

#endif
