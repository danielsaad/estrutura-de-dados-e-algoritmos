#ifndef SELECTION_SORT_H_INCLUDED
#define SELECTION_SORT_H_INCLUDED
#include <stdlib.h>

void selection_sort(int* v, size_t size);

#endif