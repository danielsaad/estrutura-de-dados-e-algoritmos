#ifndef HEAP_SORT_H_INCLUDED
#define HEAP_SORT_H_INCLUDED
#include <stdlib.h>

void heap_sort(int* v,size_t size);

#endif
